credits: https://vvcares.com

this is simple php gallery script with ADMIN logins (php hashed).
Just upload your photos on desired images folders & will auto appear on the front end.

Or
Just create new folder & assign that path inside index.php