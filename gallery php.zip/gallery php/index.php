<!DOCTYPE html><html lang="en-US"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Gallery</title><h1 class="entry-title" itemprop="headline" style="color: #fff;" itemprop="headline">GALLERY</h1>

<div class="container"><link rel='stylesheet' id='vv-google-fonts' href='style.css'type='text/css' media='all' />
<script type='text/javascript' src='js.js'></script>

<div class="padding1"><h2>ROOFING WORKS</h2><div class="padding1"><?php $directory = "images/gallery/roofing/";include 'gallery.php'; ?></div>
<div class="padding1"><h2>WATERPROOFING WORKS</h2>
<?php $directory = "images/gallery/waterproofing/";include 'gallery.php'; ?></div>
<h2>AWNING WORKS</h2>
<div class="padding1"><?php $directory = "images/gallery/awning/";include 'gallery.php'; ?></div>

</div></div>


<footer class="site-footer"></body></html>